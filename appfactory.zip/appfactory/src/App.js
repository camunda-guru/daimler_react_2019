import React, { Component } from 'react';
import Logo from './Logo/Logo'
import DaimlerMenu from './DaimlerMenu/DaimlerMenu'
class App extends Component {

    state={
        menuItems:[
            {
                id:1,name:"Dashboard"
            },
            {
                id:2,name:"NewRequest"
            },
            {
                id:3,name:"Admin"
            },
            {
                id:4,name:"Aboutus"
            }
        ]
    }

  render() {
    return (

     <header>

       <Logo/>
        <DaimlerMenu items={this.state.menuItems}/>
     </header>
    );
  }
}


export default App;
