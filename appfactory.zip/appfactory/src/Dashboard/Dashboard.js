import React from 'react'

const dashboard=()=>(
    <p>Loading Dash Board .....</p>
)

export default dashboard