import React from 'react'

const admin=()=>(
    <p>Loading Admin Page .....</p>
)

export default admin