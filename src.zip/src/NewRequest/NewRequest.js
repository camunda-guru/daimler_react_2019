import React from 'react'

const newRequest=()=>(
    <p>Loading New Request .....</p>
)

export default newRequest