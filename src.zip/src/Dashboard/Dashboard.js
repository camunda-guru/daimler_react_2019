import React,{Component} from 'react'
import axios from 'axios'
import Table from '@material-ui/core/Table'
import TableCell from '@material-ui/core/TableCell'
import TableBody from '@material-ui/core/TableBody'
import TableHead from '@material-ui/core/TableHead'
import TableRow from '@material-ui/core/TableRow'
import classes from './Dashboard.css'
/*
const dashboard=()=>(
    <p>Loading Dash Board .....</p>
)

export default dashboard*/


export class Dashboard extends Component
{
    state={
        users:[]
    }

    constructor(props)
    {
        super(props)
        console.log('[Dashboard.js] called from constructor' );
    }

    componentWillMount()
    {
        console.log('[Dashboard.js] called from component will mount' );
    }

    componentDidMount()
    {

        axios.get("https://jsonplaceholder.typicode.com/users")
            .then(response=>{
          //  console.log(response);
            this.setState({users:response.data})
                console.log(this.state.users);
        })

        console.log('[Dashboard.js] called from component did mount' );

    }
    render()
    {
        console.log('[Dashboard.js] render invoked');
        return(
            <div className={classes.Table} >
        <Table >
            <TableHead className={classes.TableHead}>
                <TableRow >
                    <TableCell>
                        Id
                    </TableCell>
                    <TableCell>
                        Name
                    </TableCell>
                    <TableCell>
                        Email
                    </TableCell>
                </TableRow>
            </TableHead>
            <TableBody>
                {
                    this.state.users.map(user=>(
                        <TableRow key={user.id} className={classes.TableRow}>
                            <TableCell>
                                {user.id}
                            </TableCell>
                            <TableCell>
                                {user.name}
                            </TableCell>
                            <TableCell>
                                {user.email}
                            </TableCell>
                        </TableRow>
                    ))
                }
            </TableBody>
        </Table>
            </div>
        )
    }

}