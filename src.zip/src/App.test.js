/*
import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';

it('renders without crashing', () => {
  const div = document.createElement('div');
  ReactDOM.render(<App />, div);
  ReactDOM.unmountComponentAtNode(div);
});
*/


import React from 'react';
import { expect } from 'chai';
import { shallow } from 'enzyme';
import 'jest-enzyme';
import sinon from 'sinon';
import App from './App';
import {configure} from "enzyme/build/index";
import Adapter from "enzyme-adapter-react-16/build/index";




configure({ adapter: new Adapter() });




it('renders without crashing', () => {
    shallow(<App />);
});
it('renders welcome message', () => {
    const wrapper = shallow(<App />);
    const welcome = <h2>Welcome to React</h2>;
    // expect(wrapper.contains(welcome)).toBe(true);
    expect(wrapper.contains(welcome)).equal(true)
});